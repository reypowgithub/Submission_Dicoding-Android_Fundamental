package com.example.submission1.data

data class User(
    val login : String,
    val id : Int,
    val avatar_url : String,
    val type : String,
)
