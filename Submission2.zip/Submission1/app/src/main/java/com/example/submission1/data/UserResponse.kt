package com.example.submission1.data

data class UserResponse(
    val items : ArrayList<User>
)